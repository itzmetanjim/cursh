import cursh.cli
cursh.cli.main()